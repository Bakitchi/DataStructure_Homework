// DataGenerator.java 抽象的数据生成器
public abstract class DataGenerator{
  abstract int[] generate(int size);
}