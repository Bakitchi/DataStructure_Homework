// Timeable.java 计时器接口
public interface Timeable{
  void run();
  void reset();
}