//�Թ���
import java.util.ArrayList;
import java.util.Random;
public class Maze implements Functions {
	public
		final char resultSymbol = '#';
		final char wallSymbolH = '-';
		final char wallSymbolV = '|';
		final char wallCorner = '+';
		final char roomSymbol = ' ';
	    ArrayList<String> record = new ArrayList<String>();
	
		char[][] maze;  		 //�Թ���̬��ά����
		int row;        	 	//�Թ���̬��ά����һ�еĳ���
		int column;      		//�Թ���̬��ά����һ�еĳ���
		int [] unionFindSet;	//�����Թ��õĲ��鼯
		int UFSLength;			//���鼯�ĳ��ȣ�Ҳ�Ƿ�����ܸ���
		
		Maze(int pRow, int pColumn) {
			row = 2*pRow + 1;
			column = 2*pColumn + 1;
			UFSLength = pRow * pColumn;
			maze = initMaze(pRow, pColumn, maze);
			unionFindSet = initUnionFindSet(unionFindSet);
	 
			maze = makeMaze(maze);
			System.out.println("�Թ������ʼ�����"+"\n");
		}    	 //���캯��

	
	@Override
	public char[][] initMaze(int row, int column, char[][] maze) {
		// TODO Auto-generated method stub
		 int realRow = 2*row + 1;
		    int realColumn = 2*column + 1;
		    maze = new char[realColumn][realRow];
		     
		    //��ʼ��ԭʼ�Թ�����
		    for (int i = 0; i < realColumn; i++)
		    {
		        for (int j = 0; j < realRow; j++)
		        {
		            if (i%2==0 && j%2==0)
		            {
		                maze[i][j] = wallCorner;
		            }
		            else if (i%2==0 && j%2==1)
		            {
		                maze[i][j] = wallSymbolH;
		            }
		            else if (i%2==1 && j%2==0)
		            {
		                maze[i][j] = wallSymbolV;
		            }
		            else
		            {
		                maze[i][j] = roomSymbol;
		            }
		        }
		    }
		    //��������
		    maze[0][1] = roomSymbol;
		    maze[realColumn - 1][realRow - 2] = roomSymbol;
		    return maze;
	}

	@Override
	public char[][] makeMaze(char[][] maze) {
		// TODO Auto-generated method stub
		long t = System.currentTimeMillis();//��õ�ǰʱ��ĺ�����
        Random rd = new Random(t);//��Ϊ���������뵽Random�Ĺ�������
        while (!isJioned(mazeAdapter(1,1), mazeAdapter(column-2, row-2)))//�����յ㲻��ͨ
        {
            int i = rd.nextInt(column-1);
            int j = rd.nextInt(row-1);
            if (i != 0 && i != column && j != 0 && j != row) // �Ǳ߽�ǽ
            {
                if ((i%2 != 1 && j%2 != 0))//������ǽ����"|"
                {
                    uionSet(mazeAdapter(i-1,j), mazeAdapter(i+1, j));
                    maze[i][j] = roomSymbol;
     
                }
                else if ((i%2 != 0 && j%2 != 1))//������ǽ����"-"
                {
                    uionSet(mazeAdapter(i,j-1), mazeAdapter(i, j+1));
                    maze[i][j] = roomSymbol;
                }
            }
        }
        return maze;
	}

	@Override
	public char[][] solveMaze(char[][] maze) {
		// TODO Auto-generated method stub
		reStore(maze);
	    int i = 1;
	    int j = 1;
	    char step = resultSymbol;
	    DFS(maze, i, j, step);
	    System.out.print("\n");
	    maze[i][j] = step;			//below start
	    maze[i-1][j] = step;		//start
	    maze[column-1][row-2] = step;//end
	    for (int i1 = 0; i1 < column; i1++)
	    {
	        for (int j1 = 0; j1 < row; j1++)
	        {
	            if ((i1%2 == 1 && j1%2 == 1) && maze[i1][j1] == '$')
	            {
	                maze[i1][j1] = roomSymbol;

	            }
	        }
	    }
	    
	    //���·���������伴��
	    System.out.println("·����ʾ��ͼʾ���£��������ҷֱ���NSWE��ʾ����");
	    System.out.print("S");
	    for(int i3 = 1; i3 < record.size();i3++){
	    	System.out.print(record.get(record.size()-i3));
	    }
	    System.out.print("S");
	    System.out.print("\n");
	    return maze;	
	}
	
	@Override
	public boolean DFS(char[][] maze, int i, int j, char step)
	{
	    maze[i][j] = '$';
	    //above end
	    if ((i == column - 2) && (j == row - 2))
	    {
	        maze[i][j] = step;
	        return true;
	    }
	    else
	    {
	        if (maze[i][j-1] == roomSymbol && maze[i][j-2] == roomSymbol && DFS(maze, i, j-2, step))//left
	        {
	            maze[i][j-1] = step;
	            maze[i][j-2] = step;
	            record.add("WW");
//	            System.out.print("WW");
	            return true;
	        }
	        if (maze[i+1][j] == roomSymbol && maze[i+2][j] == roomSymbol && DFS(maze, i+2, j, step))//down
	        {
	            maze[i+1][j] = step;
	            maze[i+2][j] = step;
	            record.add("SS");
//	            System.out.print("SS");
	            return true;
	        }
	        if (maze[i][j+1] == roomSymbol && maze[i][j+2] == roomSymbol && DFS(maze, i, j+2, step))//right
	        {
	            maze[i][j+1] = step;
	            maze[i][j+2] = step;
	            record.add("EE");
//	            System.out.print("EE");
	            return true;
	        }
	        if (maze[i-1][j] == roomSymbol && (i != 1 && j!= 1) && maze[i-2][j] == roomSymbol && DFS(maze, i-2, j, step))//up
	        {
	            maze[i-1][j] = step;
	            maze[i-2][j] = step;
	            record.add("EE");
//	            System.out.print("NN");
	            return true;
	        }
	        return false;
	    }
	   }
	    

	@Override
	public int[] initUnionFindSet(int[] unionFindSet) {
		// TODO Auto-generated method stub
		unionFindSet = new int[UFSLength];
	    for (int i = 0; i < UFSLength; i++)
	    {
	        unionFindSet[i] = i;
	    }
		return unionFindSet;
	}

	@Override
	public int mazeAdapter(int i_column, int j_row) {
		// TODO Auto-generated method stub
		return (row - 1)/2 * ((i_column+1)/2 - 1) + ((j_row+1)/2 -1);
	}

	@Override
	public int findSet(int x) {
		// TODO Auto-generated method stub
		//���Ҹ����
	    int r = x;
	    while (r != unionFindSet[r])
	        r = unionFindSet[r];
	    //·��ѹ��
	    int i = x;
	    int j;
	    while (i != r)
	    {
	        j = unionFindSet[i];
	        unionFindSet[i] = r;
	        i = j;
	    }
	    //���ظ����
	    return r;
	}

	@Override
	public void uionSet(int x, int y) {
		// TODO Auto-generated method stub
		//����x��y�ĸ����
	    int fx = findSet(x), fy = findSet(y);
	    if (fx != fy)//���x��y�ĸ���㲻��ͬ
	        unionFindSet[fx] = fy;
	}

	@Override
	public boolean isJioned(int x, int y) {
		// TODO Auto-generated method stub
		//����x��y�ĸ����
	    int fx = findSet(x), fy = findSet(y);
	    if (fx == fy)//���x��y�ĸ���㲻��ͬ
	        return true;
	    else
	        return false;
	}

	@Override
	public void printMaze(char[][] maze) {
		// TODO Auto-generated method stub
		for (int i = 0; i < column; i++)
	    {
	        for (int j = 0; j < row; j++)
	        {
	            System.out.print(maze[i][j]);
	        }
	        System.out.print("\n");
	    }
	}


	@Override
	public void printResultOfMaze() {
		// TODO Auto-generated method stub
		maze = solveMaze(maze);
		printMaze(maze);
	}

	@Override
	public char[][] reStore(char[][] maze) {
		for (int i = 0; i < column; i++)
		{
			for (int j = 0; j < row; j++)
			{
				if ((maze[i][j] != wallCorner) && (maze[i][j] != wallSymbolH) && (maze[i][j] != wallSymbolV))
				{
					maze[i][j] = roomSymbol;
				}
			}
		}
		return maze;
	}

}
